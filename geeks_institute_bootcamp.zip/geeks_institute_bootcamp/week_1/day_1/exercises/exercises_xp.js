// ===== Exercise 1

// ===== Exercise 2

// ===== Exercise 3

// ===== Exercise 4

// ===== Exercise ...